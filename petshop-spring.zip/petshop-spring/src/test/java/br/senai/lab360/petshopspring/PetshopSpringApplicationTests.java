package br.senai.lab360.petshopspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetshopSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
